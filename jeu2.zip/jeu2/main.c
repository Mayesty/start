#include <stdio.h>
#include <stdlib.h>
#include<string.h>

#include"joueur.h"
#include"chiffres.h"
#include"Lettres.h"
#include"result.h"

int main()
{/*
    printf("------------*************************************************----------------\n\n");

    printf(" ____________________________________________________________________________\n\n");
    printf("           BIENVENUE DANS LE JEU LES CHIFFRES ET LES LETTRES                            \n\n");
    printf(" ____________________________________________________________________________\n\n");
     printf("------------VOUS ETES EN MODE ENTRAINENEMT------------------------------------\n\n");
      printf("*******PARTIE 1 : LES LETTRES\n");
    printf("*******PARTIE 2 : LES CHIFFRES\n");
    printf("*******PARTIE 3 : LE DUEL\n\n");


    printf(" Le but est de trouver a travers des op�rations math�matiques proposees \n");
    printf(" dans le tableau de signes, le resultat a trouver a partir des nombres\n");
    printf("  tires.Vous n'utiliserez qu'un nombre une seule fois, vous pouvez  \n");
    printf(" reutiliser les resultats de vos operations une seule fois egalement  \n");
    printf("Vous gagnez des points si votre resultat est exact au nombre a trouver \n");
    printf("ou  proche d'une difference de 5\n\n");

    printf("--------------------A VOUS DE JOUER*****BONNE CHANCE------------------------\n\n");
    printf("----------------------------------------------------------------------------\n\n\n\n\n\n\n");*/

    char nom[10];

    printf("Nous allons commencer par votre profil,veuillez saisir un  surnom\n\n");
    scanf("%s",nom);

    int i;
    char*mot;
    int taille_mot=10;
    mot=(char*)malloc(sizeof(int)*taille_mot);

  printf("\n\n");

    printf("BIENVENUE ~.~%2s",nom);
    Player*pPlayer=initplayer(nom);
    profil(pPlayer,nom);
    printf("\n\n");
    printf("PREMIERE PARTIE : LES LETTRE\n\n");
    printf("DEBUT DU TIRAGE\n");



   for(i=1;i<11;i++)
    {
     demande_lettre();
    }
    printf("\n");
    printf("VEUILLEZ SAISIR VOTRE MOT\n");
    scanf("%s",mot);
    motexiste(pPlayer,mot);
    pPlayer->mot=mot;

    Chiffres *pChiffres;
    pChiffres=initabchif(6);
    Results *pResults;
    pResults=initialisation_pile(6);
    printf("\n\n");

   /* printf("TABLEAU DE NOMBRES------RESUTAT  A TROUVER\n\n");
    affiche_tabchif(*pChiffres);

        char **operateurs;

        int taille=3;

      operateurs=(char**)malloc(sizeof(char*)*taille);
      for( i=0; i<taille;i++)
        operateurs[i]=(char*)malloc(sizeof(char)*taille);

        int j;

        operateurs[0][0]='+';
        operateurs[0][1]='-';
        operateurs[1][0]='x';
        operateurs[1][1]='/';
        operateurs[2][1]='R';
        operateurs[2][2]='E';
          printf("\n\n");

     for(i=0;i<3;i++)
    {
        for(j=0; j<3; j++)
        {
            printf("|%2c",operateurs[i][j]);

        }
        printf("|\n");
    }
  printf("\n\n\n");
  choixope();*/
free(pPlayer);
free(pChiffres);
free(pResults);







    return 0;
}
