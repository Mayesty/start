#include "joueur.h"
#include"Lettres.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

Player*initplayer(char *name)
{
    Player*j;
    j=(Player*)malloc(sizeof(Player));
    j->surname[10]=name[10];
    return j;

}
void demande_lettre()
{
    char tabvoyel[71]={"AAAAEEEEEEIIIIIIIOOOOOOOUUUUUUUUUUAAAAAAAAAEEEEEEIIIIIIIOOOOOOOOUUUUUUU"};
    char tabconso[63]={"BBBCCCDDDFFFGGGHHHJJJKKKLLLMMMNNNPPPQQQRRRSSSTTTVVVWWWXXXYYYZZZ"};
    Lettres*l;
    l=initialisation_tabLet(10);
    char lettre;
    int indice;
    int choix;
    char choix2;

      printf(" 0 : pour quitter la partie");
      printf(" 1  : pour tirer une lettre\n");
      printf("entrer votre choix\n");



    while(choix!=0)
    {
        scanf("%d",&choix);
        switch(choix)
        {
        case 0 :  printf("AUREVOIR\n");
        break;
        case 1:  printf("saisir lettre c:consonne / v:voyelle\n");
                 scanf("%c",&choix2);
                 if(choix2=='v')
                 {
                     indice=rand()%(1+70);
                     lettre=tabvoyel[indice];
                 }
                 else if(choix2=='c')
                 {
                     indice=rand()%(1+62);
                   lettre=tabconso[indice];
                 }
                 printf("%c",lettre);
                 printf("\n");
                 empiler_lettre(l,lettre);
                 break;
        }
    printf("TIRAGE FINAL\n");
    affichage_tablettres(*l);
    printf("\n\n");
   }
}

 void motexiste(Player *p,char*mot)
 {

  int score;
  int existe = 0;
  char mot_bis[26];
  FILE *entree;

    entree = fopen ("dico.txt", "r");
    while (!feof(entree) && strcmp(mot_bis,mot)!=0)
    {
      fscanf(entree,"%s",mot_bis);
      if (strcmp(mot_bis,mot)==0)
        {
        printf ("Bravo ! Le mot existe ! \n");
        existe=1;
        score=strlen(mot);
        printf("Votre score du mot est de : %2d",score);
      }
    }
  if(!existe)
  {
    printf ("Le mot %s n'existe pas!\n",mot);
    score=0;
    printf("votre score est : %d",score);
 }
 p->score=score;
 }


void profil(Player *p)
{
    char*nom;
    nom=p->surname;
    FILE*fp;
    fp=fopen("profil.txt","a+");
    if(fp==NULL)
    {
        printf("IMPOSSIBLE D'OUVRIR LE FICHIER\n");
    }
    else
    {


        fprintf(fp,"Le nom du joeur est %s :",nom);
        fclose(fp);

    }
}
